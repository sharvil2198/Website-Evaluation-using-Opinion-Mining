import tweepy
import json
from tweepy import Stream
from local_config8 import *
import pandas as pd
import nltk
from nltk.tokenize import sent_tokenize
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.probability import FreqDist
from textblob import TextBlob
import requests
from bs4 import BeautifulSoup
import numpy as np
import json

try:
    nltk.download('punkt', download_dir='/opt/python/current/app')
except:
    nltk.download('punkt')

try:
    nltk.download('stopwords', download_dir='/opt/python/current/app')
except:
    nltk.download('stopwords')

res = []

db = pd.DataFrame(columns=['username', 'description', 'location', 'following', 'followers', 'totaltweets', 'retweetcount', 'text', 'hashtags']) 

def auth_data():
    auth = tweepy.OAuthHandler(cons_tok, cons_sec)
    auth.set_access_token(app_tok, app_sec)
    twitter_api = tweepy.API(auth,wait_on_rate_limit=True,wait_on_rate_limit_notify=True)
    return (twitter_api)

def search_data(twitter_api,searchdata = "python"):

    search_results = tweepy.Cursor(twitter_api.search, q=searchdata, tweet_mode='extended').items(100)

    list_tweets = [tweet for tweet in search_results] 

    i = 1  
      
    # we will iterate over each tweet in the list for extracting information about each tweet 
    for tweet in list_tweets: 
        username = tweet.user.screen_name 
        description = tweet.user.description 
        location = tweet.user.location 
        following = tweet.user.friends_count 
        followers = tweet.user.followers_count 
        totaltweets = tweet.user.statuses_count 
        retweetcount = tweet.retweet_count 
        hashtags = tweet.entities['hashtags'] 
            
    # Retweets can be distinguished by a retweeted_status attribute, 
    # in case it is an invalid reference, except block will be executed 
        try: 
            text = tweet.retweeted_status.full_text 
        except AttributeError: 
            text = tweet.full_text 
        hashtext = list() 
        for j in range(0, len(hashtags)): 
            hashtext.append(hashtags[j]['text']) 
            
    # Here we are appending all the extracted information in the DataFrame 
        ith_tweet = [username, description, location, following, followers, totaltweets, retweetcount, text, hashtext] 
        db.loc[len(db)] = ith_tweet 
            
        i = i+1

    return(db)

def scrape_data(company):

    url = "https://ca.trustpilot.com/review/"
    p = "www."
    s = ".com"
    req = requests.get(url+p+company+s)
    text = req.content

    soup = BeautifulSoup(text)
    reviews = soup.find_all(class_='review-card')

    review_data = []

    for i in range(len(reviews)):
        
        con = reviews[i].script.contents
        
        con1 = json.dumps(con)
        con2 = con1.split(',')
        
        try:
        
            review_data.append(
            {
                'URL': con2[0].strip().split('\\"')[3],
                'business_unit':con2[2].strip().split('\\"')[3],
                'reviewer_id':con2[3].strip().split('\\"')[3],
                'reviewer_name':con2[4].strip().split('\\"')[3],
                'review_header':con2[6].strip().split('\\"')[3],
                'text':reviews[i].p.text.strip(),
                'star_rating': [s for s in con2[-1].strip().split('\\"')[2] if s.isdigit()],
                'location':reviews[i].div.contents[3].contents[3].text.strip(),
                'count_review_by_user':reviews[i].div.contents[3].contents[1].text.strip()
            }
            )
        
        except:
            continue

    r_df = pd.DataFrame(review_data)

    return(r_df)


def show_opinion(x):
    
    tokenized_text=sent_tokenize(x)
    add=0
    avg = 0
    count = 0
    
    sentiment = ''
    
    stop_words=set(stopwords.words())

    for sent in tokenized_text:
        if (sent not in stop_words):
            if sent == '[]':
                res = TextBlob(titles1[i]).sentiment.polarity
                print("sentence : \t\t",titles1[i])
            else:
                res = TextBlob(sent).sentiment.polarity

            add +=res
            count+=1
        
    if count != 0:
        avg = add/count

    if avg > 0.01:
        opinion =  "Positive"
    elif avg < -0.01:
        opinion = "Negative"
    else:
        opinion = "Neutral"
  
    return round(avg,2),opinion