cons_tok = 'lIhxmPYKEwOpeGgJvCK6uzR0b'
cons_sec = '82qOELfTrtqzQZmcfiIf0c4VI6SANmbGwC80VGGySiNthRqO9H'

app_tok = '586532901-HlUyDLYdrzpxRogzSrhLpy3Ts4yflYZbWNdOIFd2'
app_sec = 'iQIg2GYmBFrhuqE34gnJAd4vl7cP64GLzvRsHG9SEcsLX'