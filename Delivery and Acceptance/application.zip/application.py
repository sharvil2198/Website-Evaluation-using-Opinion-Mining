from flask import Flask, request, render_template,redirect
from db import *
import pandas as pd
import json
import re

lst = []

# instantiate the Flask application.
application = Flask(__name__)

# This is the / route, or the main landing page route.
@application.route("/")
def main():
	# we will use Flask's render_template method to render a website template.
    return render_template("homepage.html")

@application.route('/tsearch', methods=['GET','POST'])
def search():
    if request.method == 'GET':
        return render_template ("tsearch.html")
    
    if request.method == 'POST':
        global g_df
    
        searchdata = str(request.form['search'])
    
        apis = auth_data()
    
        df = search_data(apis,searchdata)
    
        g_df = df

        return render_template ("tsearchtweets.html",tables=[df.to_html(classes='data')], titles=df.columns.values)

@application.route('/tpsearch', methods=['GET','POST'])
def search1():
    if request.method == 'GET':
        return render_template ("tpsearch.html")
    
    if request.method == 'POST':
        global g_df
    
        searchdata = str(request.form['search'])
    
        df = scrape_data(searchdata)
    
        g_df = df

        return render_template ("tsearchtweets.html",tables=[df.to_html(classes='data')], titles=df.columns.values)

@application.route("/tdisplayopinion")
def display_opinion():
    g_df['opinion'] = g_df.text.apply(lambda x: show_opinion(x))
    g_df[['score','sent']]= g_df.opinion.apply(lambda x: pd.Series(str(x).split()))
    g_df['sent'] = g_df.sent.apply(lambda x:re.sub(r'[^\w\s]','',x))
    k = g_df.sent.value_counts()
    dat = {}
    dat['opinion'] = 'percentage'
    for i,j in k.items():
        dat[i] = j
    return render_template('pie-chart.html', data = dat)

# run the flask application.

if __name__ == "__main__":

	application.run(debug=True)
	
